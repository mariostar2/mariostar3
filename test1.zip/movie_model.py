class MovieModeler:
    def __init__(self,title,rating,small_cover_image,summary):
        self.title = title
        self.rating = rating
        self.small_cover_image = small_cover_image
        self.summary = summary